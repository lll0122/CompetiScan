import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from ucimlrepo import fetch_ucirepo
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import confusion_matrix, classification_report
import plotly.express as px

# Set page configuration
st.set_page_config(page_title="Iris Dataset Analysis", layout="wide")

# Title
st.title("Iris Dataset Analysis and Machine Learning")

# Fetch data
@st.cache_data
def load_data():
    iris = fetch_ucirepo(id=53)
    X = iris.data.features
    y = iris.data.targets
    return X, y

X, y = load_data()
df = pd.concat([X, y], axis=1)

# Sidebar
st.sidebar.header("Navigation")
page = st.sidebar.radio("Go to", ["Data Overview", "Visualizations", "Machine Learning"])

if page == "Data Overview":
    st.header("Data Overview")
    
    # Display basic information
    st.subheader("First Few Rows")
    st.dataframe(df.head())
    
    st.subheader("Dataset Shape")
    st.write(f"Rows: {df.shape[0]}, Columns: {df.shape[1]}")
    
    st.subheader("Statistical Summary")
    st.dataframe(df.describe())
    
    st.subheader("Class Distribution")
    st.write(df['class'].value_counts())

elif page == "Visualizations":
    st.header("Data Visualizations")
    
    # Visualization options
    viz_type = st.selectbox(
        "Choose Visualization",
        ["Histograms", "Box Plots", "Scatter Plot", "Correlation Matrix"]
    )
    
    if viz_type == "Histograms":
        st.subheader("Feature Distributions by Species")
        feature = st.selectbox("Select Feature", X.columns)
        
        fig = plt.figure(figsize=(10, 6))
        for species in df['class'].unique():
            plt.hist(df[df['class'] == species][feature], 
                    alpha=0.5, label=species, bins=20)
        plt.title(f'{feature} Distribution by Species')
        plt.xlabel(feature)
        plt.ylabel('Count')
        plt.legend()
        st.pyplot(fig)
    
    elif viz_type == "Box Plots":
        st.subheader("Box Plots by Feature")
        fig = plt.figure(figsize=(10, 6))
        sns.boxplot(data=df.melt(id_vars=['class'], value_vars=X.columns), 
                   x='variable', y='value', hue='class')
        plt.xticks(rotation=45)
        plt.tight_layout()
        st.pyplot(fig)
    
    elif viz_type == "Scatter Plot":
        st.subheader("Scatter Plot")
        x_feature = st.selectbox("Select X-axis feature", X.columns)
        y_feature = st.selectbox("Select Y-axis feature", X.columns)
        
        fig = px.scatter(df, x=x_feature, y=y_feature, color='class',
                        title=f'{x_feature} vs {y_feature}')
        st.plotly_chart(fig)
    
    elif viz_type == "Correlation Matrix":
        st.subheader("Feature Correlation Matrix")
        fig = plt.figure(figsize=(10, 8))
        sns.heatmap(X.corr(), annot=True, cmap='coolwarm')
        plt.tight_layout()
        st.pyplot(fig)

else:  # Machine Learning
    st.header("Machine Learning Analysis")
    
    # Model parameters
    st.subheader("Model Parameters")
    n_estimators = st.slider("Number of trees", 10, 200, 100)
    test_size = st.slider("Test set size", 0.1, 0.4, 0.2)
    
    if st.button("Train Model"):
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=test_size, random_state=42, stratify=y
        )
        
        # Train model
        with st.spinner("Training model..."):
            rf = RandomForestClassifier(n_estimators=n_estimators, random_state=42)
            rf.fit(X_train, y_train.values.ravel())
            y_pred = rf.predict(X_test)
        
        # Display results
        st.success("Model trained successfully!")
        
        # Confusion Matrix
        st.subheader("Confusion Matrix")
        cm = confusion_matrix(y_test, y_pred)
        fig, ax = plt.subplots(figsize=(8, 6))
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                   xticklabels=rf.classes_,
                   yticklabels=rf.classes_)
        plt.title('Confusion Matrix')
        plt.xlabel('Predicted')
        plt.ylabel('True')
        st.pyplot(fig)
        
        # Classification Report
        st.subheader("Classification Report")
        st.text(classification_report(y_test, y_pred))
        
        # Feature Importance
        st.subheader("Feature Importance")
        feature_importance = pd.DataFrame({
            'feature': X.columns,
            'importance': rf.feature_importances_
        }).sort_values('importance', ascending=False)
        
        fig = plt.figure(figsize=(10, 6))
        sns.barplot(data=feature_importance, x='importance', y='feature')
        plt.title('Feature Importance')
        plt.xlabel('Importance')
        plt.tight_layout()
        st.pyplot(fig)

# Footer
st.sidebar.markdown("---")
st.sidebar.markdown("Created with Streamlit")

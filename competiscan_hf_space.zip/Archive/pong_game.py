import pygame
import sys
import random

# Initialize Pygame
pygame.init()

# Constants
WINDOW_WIDTH = 800
WINDOW_HEIGHT = 600
PADDLE_WIDTH = 15
PADDLE_HEIGHT = 90
BALL_SIZE = 15
PADDLE_SPEED = 5
BALL_SPEED = 7

# Colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)

# Initialize window
screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption('Pong Game')
clock = pygame.time.Clock()

class Paddle:
    def __init__(self, x, y):
        self.rect = pygame.Rect(x, y, PADDLE_WIDTH, PADDLE_HEIGHT)
        self.score = 0
        self.speed = PADDLE_SPEED

    def move(self, up=True):
        if up and self.rect.top > 0:
            self.rect.y -= self.speed
        if not up and self.rect.bottom < WINDOW_HEIGHT:
            self.rect.y += self.speed

    def draw(self, surface):
        pygame.draw.rect(surface, WHITE, self.rect)

class Ball:
    def __init__(self):
        self.reset()
        
    def reset(self):
        self.rect = pygame.Rect(WINDOW_WIDTH // 2 - BALL_SIZE // 2,
                              WINDOW_HEIGHT // 2 - BALL_SIZE // 2,
                              BALL_SIZE, BALL_SIZE)
        self.speed_x = BALL_SPEED * random.choice((1, -1))
        self.speed_y = BALL_SPEED * random.choice((1, -1))

    def move(self):
        self.rect.x += self.speed_x
        self.rect.y += self.speed_y

        # Wall collision (top/bottom)
        if self.rect.top <= 0 or self.rect.bottom >= WINDOW_HEIGHT:
            self.speed_y *= -1

    def draw(self, surface):
        pygame.draw.rect(surface, WHITE, self.rect)

def main():
    # Create game objects
    left_paddle = Paddle(20, WINDOW_HEIGHT // 2 - PADDLE_HEIGHT // 2)
    right_paddle = Paddle(WINDOW_WIDTH - 20 - PADDLE_WIDTH, 
                         WINDOW_HEIGHT // 2 - PADDLE_HEIGHT // 2)
    ball = Ball()

    # Font for score display
    font = pygame.font.Font(None, 36)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return  # Return to main menu instead of quitting
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    return  # Return to main menu on ESC

        # Paddle controls
        keys = pygame.key.get_pressed()
        # Left paddle (W/S keys)
        if keys[pygame.K_w]:
            left_paddle.move(up=True)
        if keys[pygame.K_s]:
            left_paddle.move(up=False)
        # Right paddle (Up/Down arrows)
        if keys[pygame.K_UP]:
            right_paddle.move(up=True)
        if keys[pygame.K_DOWN]:
            right_paddle.move(up=False)

        # Move ball
        ball.move()

        # Paddle collision
        if ball.rect.colliderect(left_paddle.rect) or \
           ball.rect.colliderect(right_paddle.rect):
            ball.speed_x *= -1

        # Scoring
        if ball.rect.left <= 0:
            right_paddle.score += 1
            ball.reset()
        elif ball.rect.right >= WINDOW_WIDTH:
            left_paddle.score += 1
            ball.reset()

        # Drawing
        screen.fill(BLACK)
        left_paddle.draw(screen)
        right_paddle.draw(screen)
        ball.draw(screen)

        # Draw scores
        left_score = font.render(str(left_paddle.score), True, WHITE)
        right_score = font.render(str(right_paddle.score), True, WHITE)
        screen.blit(left_score, (WINDOW_WIDTH // 4, 20))
        screen.blit(right_score, (3 * WINDOW_WIDTH // 4, 20))

        # Draw center line
        pygame.draw.aaline(screen, WHITE, 
                          (WINDOW_WIDTH // 2, 0),
                          (WINDOW_WIDTH // 2, WINDOW_HEIGHT))

        pygame.display.flip()
        clock.tick(60)

if __name__ == '__main__':
    main()

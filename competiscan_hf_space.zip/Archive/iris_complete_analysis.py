import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from ucimlrepo import fetch_ucirepo
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

# Set style for better visualizations
plt.style.use('seaborn')
sns.set_palette("husl")

# Fetch the iris dataset
iris = fetch_ucirepo(id=53)
X = iris.data.features
y = iris.data.targets

# Combine features and target into one dataframe
df = pd.concat([X, y], axis=1)

# 1. Basic Data Exploration
print("\n=== Basic Data Exploration ===")
print("\nFirst 5 rows:")
print(df.head())

print("\nDataset Shape:", df.shape)

print("\nDataset Info:")
print(df.info())

print("\nStatistical Summary:")
print(df.describe())

print("\nMissing Values:")
print(df.isnull().sum())

print("\nClass Distribution:")
print(df['class'].value_counts())

# 2. Visualizations

# 2.1 Histograms for each feature
plt.figure(figsize=(12, 8))
for i, feature in enumerate(X.columns):
    plt.subplot(2, 2, i+1)
    for species in df['class'].unique():
        subset = df[df['class'] == species]
        plt.hist(subset[feature], bins=20, alpha=0.5, label=species)
    plt.title(f'{feature} Distribution by Species')
    plt.xlabel(feature)
    plt.ylabel('Count')
    plt.legend()
plt.tight_layout()
plt.savefig('iris_histograms.png')
plt.close()

# 2.2 Box plots
plt.figure(figsize=(10, 6))
df.boxplot(column=X.columns, by='class')
plt.title('Feature Distribution by Species')
plt.suptitle('')  # This removes the automatic suptitle
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig('iris_boxplots.png')
plt.close()

# 2.3 Correlation Matrix
plt.figure(figsize=(10, 8))
correlation_matrix = df[X.columns].corr()
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', vmin=-1, vmax=1)
plt.title('Feature Correlation Matrix')
plt.tight_layout()
plt.savefig('iris_correlation.png')
plt.close()

# 2.4 Pair Plot
sns.pairplot(df, hue='class', diag_kind='hist')
plt.savefig('iris_pairplot.png')
plt.close()

# 3. PCA Analysis
# Standardize the features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Apply PCA
pca = PCA()
X_pca = pca.fit_transform(X_scaled)

# Plot explained variance ratio
plt.figure(figsize=(10, 6))
plt.plot(range(1, len(pca.explained_variance_ratio_) + 1), 
         np.cumsum(pca.explained_variance_ratio_), 'bo-')
plt.xlabel('Number of Components')
plt.ylabel('Cumulative Explained Variance Ratio')
plt.title('PCA Explained Variance Ratio')
plt.grid(True)
plt.savefig('iris_pca_variance.png')
plt.close()

# Plot first two principal components
plt.figure(figsize=(10, 8))
for species in df['class'].unique():
    mask = df['class'] == species
    plt.scatter(X_pca[mask, 0], X_pca[mask, 1], label=species, alpha=0.7)
plt.xlabel('First Principal Component')
plt.ylabel('Second Principal Component')
plt.title('PCA of Iris Dataset')
plt.legend()
plt.grid(True)
plt.savefig('iris_pca_scatter.png')
plt.close()

# 4. Summary Statistics by Species
print("\n=== Summary Statistics by Species ===")
for species in df['class'].unique():
    print(f"\nStatistics for {species}:")
    print(df[df['class'] == species][X.columns].describe())

# Save all numerical results to a text file
with open('iris_analysis_results.txt', 'w') as f:
    f.write("=== Iris Dataset Analysis Results ===\n\n")
    f.write("Dataset Shape: {}\n".format(df.shape))
    f.write("\nClass Distribution:\n{}\n".format(df['class'].value_counts()))
    f.write("\nCorrelation Matrix:\n{}\n".format(correlation_matrix))
    f.write("\nPCA Explained Variance Ratio:\n{}\n".format(pca.explained_variance_ratio_))

print("\nAnalysis complete! The following files have been created:")
print("1. iris_histograms.png - Histograms for each feature by species")
print("2. iris_boxplots.png - Box plots of features by species")
print("3. iris_correlation.png - Correlation matrix heatmap")
print("4. iris_pairplot.png - Pair plot of all features")
print("5. iris_pca_variance.png - PCA explained variance ratio")
print("6. iris_pca_scatter.png - PCA scatter plot")
print("7. iris_analysis_results.txt - Detailed numerical results")

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from ucimlrepo import fetch_ucirepo
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (confusion_matrix, classification_report, 
                           f1_score, roc_curve, auc)
from sklearn.preprocessing import label_binarize

# Set random seed for reproducibility
np.random.seed(42)

# Fetch the iris dataset
iris = fetch_ucirepo(id=53)
X = iris.data.features
y = iris.data.targets

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# Train Random Forest Classifier
rf_classifier = RandomForestClassifier(n_estimators=100, random_state=42)
rf_classifier.fit(X_train, y_train.values.ravel())

# Make predictions
y_pred = rf_classifier.predict(X_test)

# Print model performance metrics
print("\n=== Model Performance ===")
print("\nConfusion Matrix:")
cm = confusion_matrix(y_test, y_pred)
print(cm)

# Create a prettier confusion matrix plot
plt.figure(figsize=(10, 8))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
            xticklabels=rf_classifier.classes_,
            yticklabels=rf_classifier.classes_)
plt.title('Confusion Matrix')
plt.xlabel('Predicted')
plt.ylabel('True')
plt.savefig('confusion_matrix.png')
plt.close()

print("\nClassification Report:")
print(classification_report(y_test, y_pred))

print("\nOverall F1 Score:", f1_score(y_test, y_pred, average='weighted'))

# Feature Importance
feature_importance = pd.DataFrame({
    'feature': X.columns,
    'importance': rf_classifier.feature_importances_
})
feature_importance = feature_importance.sort_values('importance', ascending=False)

plt.figure(figsize=(10, 6))
sns.barplot(data=feature_importance, x='importance', y='feature')
plt.title('Feature Importance')
plt.xlabel('Importance')
plt.tight_layout()
plt.savefig('feature_importance.png')
plt.close()

# ROC Curve (One-vs-Rest)
# Binarize the output for ROC curve
y_test_bin = label_binarize(y_test, classes=rf_classifier.classes_)
y_score = rf_classifier.predict_proba(X_test)

# Compute ROC curve and ROC area for each class
fpr = dict()
tpr = dict()
roc_auc = dict()

plt.figure(figsize=(10, 8))
colors = ['blue', 'red', 'green']
for i, color in zip(range(len(rf_classifier.classes_)), colors):
    fpr[i], tpr[i], _ = roc_curve(y_test_bin[:, i], y_score[:, i])
    roc_auc[i] = auc(fpr[i], tpr[i])
    
    plt.plot(fpr[i], tpr[i], color=color, lw=2,
             label=f'ROC curve {rf_classifier.classes_[i]} (AUC = {roc_auc[i]:.2f})')

plt.plot([0, 1], [0, 1], 'k--', lw=2)
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC Curves (One-vs-Rest)')
plt.legend(loc="lower right")
plt.savefig('roc_curves.png')
plt.close()

# Print feature importance
print("\nFeature Importance:")
for idx, row in feature_importance.iterrows():
    print(f"{row['feature']}: {row['importance']:.4f}")

# Save results to file
with open('ml_analysis_results.txt', 'w') as f:
    f.write("=== Machine Learning Analysis Results ===\n\n")
    f.write("Model: Random Forest Classifier\n")
    f.write("\nConfusion Matrix:\n")
    f.write(str(cm))
    f.write("\n\nClassification Report:\n")
    f.write(classification_report(y_test, y_pred))
    f.write("\nFeature Importance:\n")
    for idx, row in feature_importance.iterrows():
        f.write(f"{row['feature']}: {row['importance']:.4f}\n")

print("\nAnalysis complete! The following files have been created:")
print("1. confusion_matrix.png - Confusion matrix heatmap")
print("2. feature_importance.png - Feature importance plot")
print("3. roc_curves.png - ROC curves for each class")
print("4. ml_analysis_results.txt - Detailed analysis results")

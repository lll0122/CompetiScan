import pygame
import sys
from snake_game import main as snake_main
from pong_game import main as pong_main

# Initialize Pygame
pygame.init()

# Constants
WINDOW_WIDTH = 800
WINDOW_HEIGHT = 600
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

def draw_menu(screen, selected_option):
    screen.fill(BLACK)
    font = pygame.font.Font(None, 74)
    
    # Title
    title = font.render("Game Menu", True, WHITE)
    title_rect = title.get_rect(center=(WINDOW_WIDTH // 2, 100))
    screen.blit(title, title_rect)
    
    # Options
    options = ["1. Snake Game", "2. Pong Game", "3. Quit"]
    y_position = 250
    
    for i, option in enumerate(options):
        color = WHITE
        if i == selected_option:
            # Highlight selected option
            text = f"> {option} <"
        else:
            text = option
        
        option_text = font.render(text, True, color)
        option_rect = option_text.get_rect(center=(WINDOW_WIDTH // 2, y_position))
        screen.blit(option_text, option_rect)
        y_position += 100

def main_menu():
    screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
    pygame.display.set_caption('Game Menu')
    clock = pygame.time.Clock()
    
    selected_option = 0
    
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    selected_option = (selected_option - 1) % 3
                elif event.key == pygame.K_DOWN:
                    selected_option = (selected_option + 1) % 3
                elif event.key == pygame.K_RETURN:
                    if selected_option == 0:  # Snake Game
                        # Reset display mode before starting snake game
                        pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
                        try:
                            snake_main()
                        except SystemExit:
                            # Reset display mode after game ends
                            pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
                            continue
                    
                    elif selected_option == 1:  # Pong Game
                        # Reset display mode before starting pong game
                        pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
                        try:
                            pong_main()
                        except SystemExit:
                            # Reset display mode after game ends
                            pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
                            continue
                    
                    elif selected_option == 2:  # Quit
                        pygame.quit()
                        sys.exit()
                
                elif event.key in (pygame.K_1, pygame.K_KP1):
                    selected_option = 0
                elif event.key in (pygame.K_2, pygame.K_KP2):
                    selected_option = 1
                elif event.key in (pygame.K_3, pygame.K_KP3):
                    selected_option = 2
        
        draw_menu(screen, selected_option)
        pygame.display.flip()
        clock.tick(60)

if __name__ == '__main__':
    main_menu()

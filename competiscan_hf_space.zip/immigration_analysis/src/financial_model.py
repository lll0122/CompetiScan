import pandas as pd
import numpy as np

class BalanceSheetProjection:
    def __init__(self):
        self.ratios = {
            'current_liabilities_to_revenue': 0.0,  # E4 in Ratios sheet
            'dividend_payout_ratio': 0.0,          # B7 in Ratios sheet
            'ar_days': 0.0,                        # E15 in Ratios sheet
            'ppe_to_revenue': 0.0,                 # E16 in Ratios sheet
            'inventory_turnover': 0.0,             # E13 in Ratios sheet
            'prepaid_growth': 0.0                  # E14 in Ratios sheet
        }
        
        self.historical_data = {
            'prepaid_other_current_assets': 0.0,   # C46
            'goodwill': 0.0,                       # C49
            'trademarks': 0.0,                     # C50
            'other_noncurrent_assets': 0.0,        # C51
            'long_term_debt': 0.0,                 # C61
            'deferred_taxes': 0.0,                 # C62
            'other_noncurrent_liab': 0.0,          # C63
            'common_stock': 0.0,                   # C72
            'esop_reserve': 0.0,                   # C73
            'accumulated_other_comp': 0.0,         # C74
            'retained_earnings_prior': 0.0,        # C75
            'noncontrolling_interest': 0.0         # C76
        }

    def project_balance_sheet(self, revenue, cogs, net_income, years):
        """
        Project balance sheet items based on revenue and other inputs
        """
        projections = pd.DataFrame(index=years)
        
        # Assets
        projections['accounts_receivable'] = revenue * (self.ratios['ar_days'] / 365)
        projections['inventory'] = cogs / self.ratios['inventory_turnover']
        
        # Calculate prepaid growth year over year
        prepaid = [self.historical_data['prepaid_other_current_assets']]
        for _ in range(len(years)-1):
            prepaid.append(prepaid[-1] * (1 + self.ratios['prepaid_growth']))
        projections['prepaid_other_current'] = prepaid
        
        # Fixed assets
        projections['net_ppe'] = revenue * self.ratios['ppe_to_revenue']
        
        # Constant values
        projections['goodwill'] = self.historical_data['goodwill']
        projections['trademarks'] = self.historical_data['trademarks']
        projections['other_noncurrent_assets'] = self.historical_data['other_noncurrent_assets']
        
        # Liabilities
        projections['current_liabilities'] = revenue * self.ratios['current_liabilities_to_revenue']
        projections['long_term_debt'] = self.historical_data['long_term_debt']
        projections['deferred_taxes'] = self.historical_data['deferred_taxes']
        projections['other_noncurrent_liab'] = self.historical_data['other_noncurrent_liab']
        
        # Equity
        projections['common_stock'] = self.historical_data['common_stock']
        projections['esop_reserve'] = self.historical_data['esop_reserve']
        projections['accumulated_other_comp'] = self.historical_data['accumulated_other_comp']
        
        # Calculate retained earnings progression
        retained_earnings = [self.historical_data['retained_earnings_prior']]
        for year_income in net_income:
            dividend = year_income * self.ratios['dividend_payout_ratio']
            retained_earnings.append(retained_earnings[-1] + year_income - dividend)
        projections['retained_earnings'] = retained_earnings[1:]  # Remove initial value
        
        projections['noncontrolling_interest'] = self.historical_data['noncontrolling_interest']
        
        # Calculate totals
        projections['total_current_assets'] = (
            projections['accounts_receivable'] + 
            projections['inventory'] + 
            projections['prepaid_other_current']
        )
        
        projections['total_noncurrent_assets'] = (
            projections['net_ppe'] + 
            projections['goodwill'] + 
            projections['trademarks'] + 
            projections['other_noncurrent_assets']
        )
        
        projections['total_assets'] = (
            projections['total_current_assets'] + 
            projections['total_noncurrent_assets']
        )
        
        projections['total_liabilities'] = (
            projections['current_liabilities'] + 
            projections['long_term_debt'] + 
            projections['deferred_taxes'] + 
            projections['other_noncurrent_liab']
        )
        
        projections['total_equity'] = (
            projections['common_stock'] + 
            projections['esop_reserve'] + 
            projections['accumulated_other_comp'] + 
            projections['retained_earnings'] + 
            projections['noncontrolling_interest']
        )
        
        projections['total_liabilities_equity'] = (
            projections['total_liabilities'] + 
            projections['total_equity']
        )
        
        # Calculate cash as the plug (total assets - sum of other assets)
        other_assets = (
            projections['accounts_receivable'] + 
            projections['inventory'] + 
            projections['prepaid_other_current'] + 
            projections['total_noncurrent_assets']
        )
        projections['cash'] = projections['total_liabilities_equity'] - other_assets
        
        return projections

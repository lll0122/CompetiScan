import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import numpy as np
import shap

def create_education_income_plot(df):
    """
    Create education vs income visualization
    """
    edu_income = df.groupby('education')['income_binary'].mean().sort_values(ascending=False)
    
    fig = px.bar(
        edu_income,
        title="Income Potential by Education Level",
        labels={'value': 'Probability of High Income', 'education': 'Education Level'},
        color=edu_income.values,
        color_continuous_scale='Viridis'
    )
    
    fig.update_layout(
        xaxis_title="Education Level",
        yaxis_title="Probability of High Income",
        showlegend=False
    )
    
    return fig

def create_age_distribution_plot(df):
    """
    Create age distribution visualization
    """
    fig = px.histogram(
        df,
        x='age',
        color='income',
        marginal="box",
        title="Age Distribution by Income Level",
        labels={'age': 'Age', 'count': 'Number of Individuals'},
        color_discrete_map={' <=50K': 'lightblue', ' >50K': 'darkblue'}
    )
    
    fig.update_layout(
        xaxis_title="Age",
        yaxis_title="Count",
        bargap=0.1
    )
    
    return fig

def create_feature_importance_plot(model, feature_names):
    """
    Create feature importance visualization
    """
    importance = pd.DataFrame({
        'Feature': feature_names,
        'Importance': model.feature_importances_
    }).sort_values('Importance', ascending=True)
    
    fig = px.bar(
        importance,
        x='Importance',
        y='Feature',
        orientation='h',
        title="Feature Importance in Economic Potential Prediction"
    )
    
    fig.update_layout(
        xaxis_title="Relative Importance",
        yaxis_title="Feature",
        showlegend=False
    )
    
    return fig

def create_shap_summary_plot(shap_values, X, feature_names):
    """
    Create SHAP summary plot for model interpretability
    """
    shap.summary_plot(shap_values, X, feature_names=feature_names, show=False)
    return plt.gcf()

def create_potential_score_distribution(df):
    """
    Create potential score distribution visualization
    """
    fig = px.histogram(
        df,
        x='potential_score',
        color='income',
        nbins=50,
        title="Distribution of Economic Potential Scores",
        labels={'potential_score': 'Economic Potential Score', 
                'count': 'Number of Individuals'},
        marginal="box"
    )
    
    fig.update_layout(
        xaxis_title="Economic Potential Score",
        yaxis_title="Count",
        bargap=0.1
    )
    
    return fig

def create_correlation_heatmap(df, columns):
    """
    Create correlation heatmap for selected features
    """
    corr = df[columns].corr()
    
    fig = px.imshow(
        corr,
        title="Feature Correlation Matrix",
        labels=dict(color="Correlation"),
        color_continuous_scale="RdBu"
    )
    
    fig.update_layout(
        xaxis_title="Features",
        yaxis_title="Features"
    )
    
    return fig

def create_prediction_gauge(score):
    """
    Create gauge chart for economic potential prediction
    """
    fig = go.Figure(go.Indicator(
        mode = "gauge+number",
        value = score * 100,
        domain = {'x': [0, 1], 'y': [0, 1]},
        title = {'text': "Economic Potential Score"},
        gauge = {
            'axis': {'range': [0, 100]},
            'bar': {'color': "darkblue"},
            'steps': [
                {'range': [0, 33], 'color': "lightgray"},
                {'range': [33, 66], 'color': "gray"},
                {'range': [66, 100], 'color': "darkgray"}
            ],
            'threshold': {
                'line': {'color': "red", 'width': 4},
                'thickness': 0.75,
                'value': 80
            }
        }
    ))
    
    return fig

def create_success_factors_radar(data):
    """
    Create radar chart for success factors
    """
    categories = list(data.keys())
    values = list(data.values())
    
    fig = go.Figure()
    
    fig.add_trace(go.Scatterpolar(
        r=values,
        theta=categories,
        fill='toself',
        name='Success Factors'
    ))
    
    fig.update_layout(
        polar=dict(
            radialaxis=dict(
                visible=True,
                range=[0, 1]
            )),
        showlegend=False,
        title="Success Factors Analysis"
    )
    
    return fig

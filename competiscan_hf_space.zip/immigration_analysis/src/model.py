import numpy as np
from sklearn.ensemble import GradientBoostingRegressor, RandomForestClassifier
from sklearn.metrics import accuracy_score, r2_score, mean_squared_error
import joblib
import shap

class EconomicPotentialModel:
    def __init__(self):
        # Model for predicting income
        self.income_model = GradientBoostingRegressor(
            n_estimators=200,
            learning_rate=0.1,
            max_depth=5,
            random_state=42
        )
        
        # Model for predicting innovation potential
        self.innovation_model = GradientBoostingRegressor(
            n_estimators=150,
            learning_rate=0.1,
            max_depth=4,
            random_state=42
        )
        
        # Model for predicting entrepreneurial success
        self.entrepreneurial_model = GradientBoostingRegressor(
            n_estimators=150,
            learning_rate=0.1,
            max_depth=4,
            random_state=42
        )
        
        # Model for overall economic potential
        self.potential_model = RandomForestClassifier(
            n_estimators=200,
            max_depth=6,
            class_weight='balanced',
            random_state=42
        )
        
        self.feature_importance = {}
        self.shap_values = {}
        self.model_performance = {}
    
    def train_models(self, X_train, y_train_dict):
        """
        Train all prediction models
        
        Args:
            X_train: Feature matrix
            y_train_dict: Dictionary containing different target variables
                        {'income': income_target,
                         'innovation': innovation_target,
                         'entrepreneurial': entrepreneurial_target,
                         'potential': potential_target}
        """
        # Train income model
        self.income_model.fit(X_train, y_train_dict['income'])
        self.feature_importance['income'] = dict(zip(
            range(X_train.shape[1]),
            self.income_model.feature_importances_
        ))
        
        # Train innovation model
        self.innovation_model.fit(X_train, y_train_dict['innovation'])
        self.feature_importance['innovation'] = dict(zip(
            range(X_train.shape[1]),
            self.innovation_model.feature_importances_
        ))
        
        # Train entrepreneurial model
        self.entrepreneurial_model.fit(X_train, y_train_dict['entrepreneurial'])
        self.feature_importance['entrepreneurial'] = dict(zip(
            range(X_train.shape[1]),
            self.entrepreneurial_model.feature_importances_
        ))
        
        # Train potential model
        self.potential_model.fit(X_train, y_train_dict['potential'])
        self.feature_importance['potential'] = dict(zip(
            range(X_train.shape[1]),
            self.potential_model.feature_importances_
        ))
        
        # Calculate SHAP values for all models
        for name, model in [
            ('income', self.income_model),
            ('innovation', self.innovation_model),
            ('entrepreneurial', self.entrepreneurial_model)
        ]:
            explainer = shap.TreeExplainer(model)
            self.shap_values[name] = explainer.shap_values(X_train)
    
    def predict(self, X):
        """
        Generate comprehensive predictions for an individual
        
        Args:
            X: Feature matrix for prediction
            
        Returns:
            Dictionary containing all predictions and a composite score
        """
        predictions = {
            'income': self.income_model.predict(X),
            'innovation': self.innovation_model.predict(X),
            'entrepreneurial': self.entrepreneurial_model.predict(X),
            'potential_prob': self.potential_model.predict_proba(X)[:, 1]
        }
        
        # Calculate composite score with weighted components
        predictions['composite_score'] = (
            0.3 * predictions['income'] +
            0.3 * predictions['innovation'] +
            0.2 * predictions['entrepreneurial'] +
            0.2 * predictions['potential_prob']
        )
        
        return predictions
    
    def evaluate_models(self, X_test, y_test_dict):
        """
        Evaluate all models' performance
        
        Args:
            X_test: Test feature matrix
            y_test_dict: Dictionary containing test target variables
        """
        predictions = self.predict(X_test)
        
        # Evaluate each model
        self.model_performance = {
            'income': {
                'r2': r2_score(y_test_dict['income'], predictions['income']),
                'rmse': np.sqrt(mean_squared_error(y_test_dict['income'], predictions['income']))
            },
            'innovation': {
                'r2': r2_score(y_test_dict['innovation'], predictions['innovation']),
                'rmse': np.sqrt(mean_squared_error(y_test_dict['innovation'], predictions['innovation']))
            },
            'entrepreneurial': {
                'r2': r2_score(y_test_dict['entrepreneurial'], predictions['entrepreneurial']),
                'rmse': np.sqrt(mean_squared_error(y_test_dict['entrepreneurial'], predictions['entrepreneurial']))
            },
            'potential': {
                'accuracy': accuracy_score(y_test_dict['potential'], (predictions['potential_prob'] > 0.5).astype(int)),
                'auc': roc_auc_score(y_test_dict['potential'], predictions['potential_prob'])
            }
        }
        
        return self.model_performance
    
    def get_feature_importance(self):
        """
        Get feature importance for both models
        """
        return self.feature_importance
    
    def get_shap_values(self):
        """
        Get SHAP values for model interpretability
        """
        return self.shap_values
    
    def save_models(self, path_prefix):
        """
        Save both models to disk
        """
        joblib.dump(self.income_model, f'{path_prefix}_income.joblib')
        joblib.dump(self.potential_model, f'{path_prefix}_potential.joblib')
    
    def load_models(self, path_prefix):
        """
        Load both models from disk
        """
        self.income_model = joblib.load(f'{path_prefix}_income.joblib')
        self.potential_model = joblib.load(f'{path_prefix}_potential.joblib')

def create_economic_profile(model, X, feature_names=None):
    """
    Create a comprehensive economic profile for an individual or group
    
    Args:
        model: Trained EconomicPotentialModel instance
        X: Feature matrix for prediction
        feature_names: List of feature names for interpretation
        
    Returns:
        Dictionary containing predictions and feature importance analysis
    """
    # Get predictions
    predictions = model.predict(X)
    
    # Get feature contributions
    contributions = {}
    for name, values in model.shap_values.items():
        if feature_names is not None:
            contributions[name] = dict(zip(feature_names, np.abs(values).mean(0)))
        else:
            contributions[name] = np.abs(values).mean(0).tolist()
    
    return {
        'predictions': predictions,
        'feature_contributions': contributions,
        'model_performance': model.model_performance
    }
    """
    Create a composite score combining income and potential predictions
    """
    # Normalize predictions to 0-1 range
    income_norm = (income_pred - income_pred.min()) / (income_pred.max() - income_pred.min())
    
    # Calculate weighted average
    return weights[0] * income_norm + weights[1] * potential_pred

if __name__ == "__main__":
    # Test model functionality
    from sklearn.datasets import make_classification
    
    # Generate sample data
    X, y = make_classification(n_samples=1000, n_features=10, n_classes=2)
    X_train, X_test = X[:800], X[800:]
    y_train, y_test = y[:800], y[800:]
    
    # Test model
    model = EconomicPotentialModel()
    model.train_income_model(X_train, y_train)
    model.train_potential_model(X_train, y_train)
    
    # Test predictions
    income_pred = model.predict_income(X_test)
    potential_pred = model.predict_potential(X_test)
    
    # Create composite score
    scores = create_composite_score(income_pred, potential_pred)
    print("Model testing completed successfully")

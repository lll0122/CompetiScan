import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.ensemble import RandomForestClassifier, GradientBoostingRegressor
from sklearn.metrics import accuracy_score, mean_squared_error, r2_score
import shap

# Page config
st.set_page_config(
    page_title="Immigration Economic Impact Analysis",
    layout="wide"
)

# Title and introduction
st.title("Immigration Economic Impact Analysis Dashboard")
st.markdown("""
This dashboard analyzes potential economic contributions of immigrants based on various factors
including education, skills, and work experience. The model provides insights for merit-based
immigration policy decisions.
""")

# Load and preprocess data
@st.cache_data
def load_data():
    from src.data_prep import load_and_clean_data, calculate_economic_metrics
    
    # Load and preprocess data
    df = load_and_clean_data('data/adult.csv')
    
    # Calculate economic metrics
    metrics, df = calculate_economic_metrics(df)
    
    return df, metrics

# Load data and initialize model
try:
    from src.model import EconomicPotentialModel, create_economic_profile
    from src.visualization import (
        create_education_income_plot,
        create_age_distribution_plot,
        create_feature_importance_plot,
        create_shap_summary_plot,
        create_potential_score_distribution,
        create_correlation_heatmap,
        create_success_factors_radar
    )
    
    # Load data
    df, metrics = load_data()
    
    # Initialize model
    model = EconomicPotentialModel()
    
    # Sidebar for navigation
    st.sidebar.title("Navigation")
    page = st.sidebar.radio(
        "Select Analysis",
        ["Overview", "Economic Potential Analysis", "Predictive Insights", "Policy Recommendations"]
    )

    if page == "Overview":
        st.header("Economic Impact Overview")
        
        # Key metrics
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            high_income_pct = (df['income_binary'].mean() * 100).round(1)
            st.metric("High Income Potential", f"{high_income_pct}%")
            
        with col2:
            avg_innovation = df['innovation_score'].mean().round(3)
            st.metric("Innovation Score", f"{avg_innovation}")
            
        with col3:
            avg_entrepreneurial = df['entrepreneurial_index'].mean().round(3)
            st.metric("Entrepreneurial Index", f"{avg_entrepreneurial}")
            
        with col4:
            avg_economic = df['economic_potential'].mean().round(3)
            st.metric("Economic Potential", f"{avg_economic}")

        # Education impact visualization
        st.subheader("Education Impact on Economic Success")
        fig = create_education_income_plot(df)
        st.plotly_chart(fig)
        
        # Success factors radar chart
        st.subheader("Key Success Factors Analysis")
        success_factors = {
            'Education': df['education_value'].mean(),
            'Innovation': df['innovation_score'].mean(),
            'Entrepreneurship': df['entrepreneurial_index'].mean(),
            'Work Hours': df['hours-per-week'].mean() / 80,
            'Income Potential': df['income_binary'].mean()
        }
        fig = create_success_factors_radar(success_factors)
        st.plotly_chart(fig)

    elif page == "Economic Potential Analysis":
        st.header("Economic Potential Analysis")
        
        # Age distribution by economic potential
        st.subheader("Age and Economic Success Relationship")
        fig = create_age_distribution_plot(df)
        st.plotly_chart(fig)
        
        # Economic potential distribution
        st.subheader("Distribution of Economic Potential Scores")
        fig = create_potential_score_distribution(df)
        st.plotly_chart(fig)
        
        # Correlation analysis
        st.subheader("Factor Correlation Analysis")
        correlation_features = [
            'education_value', 'innovation_score', 'entrepreneurial_index',
            'economic_potential', 'income_binary', 'age'
        ]
        fig = create_correlation_heatmap(df, correlation_features)
        st.plotly_chart(fig)

    elif page == "Predictive Insights":
        st.header("Predictive Model Insights")
        
        # Model performance metrics
        if model.model_performance:
            st.subheader("Model Performance Metrics")
            col1, col2 = st.columns(2)
            
            with col1:
                st.metric("Income Prediction R²", f"{model.model_performance['income']['r2']:.3f}")
                st.metric("Innovation Score R²", f"{model.model_performance['innovation']['r2']:.3f}")
            
            with col2:
                st.metric("Potential Model AUC", f"{model.model_performance['potential']['auc']:.3f}")
                st.metric("Entrepreneurial Score R²", f"{model.model_performance['entrepreneurial']['r2']:.3f}")
        
        # Feature importance visualization
        st.subheader("Feature Importance Analysis")
        feature_names = [
            'Age', 'Education', 'Work Hours', 'Occupation',
            'Work Class', 'Marital Status', 'Relationship'
        ]
        fig = create_feature_importance_plot(model.income_model, feature_names)
        st.plotly_chart(fig)
        
        # SHAP analysis
        st.subheader("SHAP Value Analysis")
        if 'income' in model.shap_values:
            fig = create_shap_summary_plot(model.shap_values['income'], df, feature_names)
            st.pyplot(fig)



    else:  # Policy Recommendations
        st.header("Policy Recommendations")
        
        st.markdown("""
        ### Key Policy Insights
        
        Based on our comprehensive analysis, we recommend the following policy considerations:
        
        1. **Education-Weighted Scoring**
           - Higher weight for advanced degrees in STEM fields
           - Additional points for specialized certifications
           - Recognition of equivalent work experience
        
        2. **Innovation Potential**
           - Emphasis on research contributions and patents
           - Consideration of startup experience
           - Technology sector expertise
        
        3. **Economic Impact Metrics**
           - Projected tax contributions
           - Job creation potential
           - Industry demand alignment
        
        4. **Integration Factors**
           - Language proficiency
           - Previous U.S. work/study experience
           - Industry-specific skills
        
        ### Implementation Framework
        
        The model suggests a point-based system with the following weights:
        - Education & Skills: 35%
        - Innovation Potential: 25%
        - Economic Impact: 25%
        - Integration Factors: 15%
        
        ### Continuous Improvement
        
        We recommend:
        1. Quarterly model updates with new economic data
        2. Annual policy adjustment based on economic needs
        3. Regular stakeholder feedback integration
        """)
        
        # Sample applicant analysis
        st.subheader("Sample Applicant Analysis")
        
        # Interactive sample analysis
        col1, col2 = st.columns(2)
        
        with col1:
            education = st.selectbox(
                "Education Level",
                ['Doctorate', 'Masters', 'Bachelors', 'Some-college', 'HS-grad']
            )
            
            occupation = st.selectbox(
                "Occupation",
                ['Tech-support', 'Prof-specialty', 'Science', 'Exec-managerial', 'Sales']
            )
            
            age = st.slider("Age", 18, 65, 30)
            
        with col2:
            work_class = st.selectbox(
                "Work Class",
                ['Private', 'Self-emp-inc', 'Self-emp-not-inc', 'Federal-gov']
            )
            
            hours = st.slider("Hours per Week", 20, 80, 40)
            
            experience = st.slider("Years of Experience", 0, 30, 5)
        
        # Create sample profile
        if st.button("Analyze Profile"):
            sample_data = pd.DataFrame({
                'age': [age],
                'education': [education],
                'occupation': [occupation],
                'workclass': [work_class],
                'hours-per-week': [hours],
                'experience': [experience]
            })
            
            # Get predictions
            profile = create_economic_profile(model, sample_data)
            
            st.subheader("Profile Analysis Results")
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.metric(
                    "Economic Potential Score",
                    f"{profile['predictions']['composite_score'][0]:.2f}"
                )
            
            with col2:
                st.metric(
                    "Innovation Score",
                    f"{profile['predictions']['innovation'][0]:.2f}"
                )
            
            with col3:
                st.metric(
                    "Entrepreneurial Score",
                    f"{profile['predictions']['entrepreneurial'][0]:.2f}"
                )
        X = df[feature_cols]
        y = df['income_binary']
        
        # Split and scale data
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        scaler = StandardScaler()
        X_train_scaled = scaler.fit_transform(X_train)
        X_test_scaled = scaler.transform(X_test)
        
        # Train model
        model = GradientBoostingRegressor(random_state=42)
        model.fit(X_train_scaled, y_train)
        
        # Model performance
        y_pred = model.predict(X_test_scaled)
        r2 = r2_score(y_test, y_pred)
        
        st.metric("Model R² Score", f"{r2:.3f}")
        
        # Feature importance
        importance_df = pd.DataFrame({
            'Feature': feature_cols,
            'Importance': model.feature_importances_
        }).sort_values('Importance', ascending=False)
        
        fig_importance = px.bar(importance_df, x='Feature', y='Importance',
                              title="Feature Importance in Predicting Economic Success")
        st.plotly_chart(fig_importance)
        
        # Interactive prediction
        st.subheader("Economic Potential Predictor")
        col1, col2, col3 = st.columns(3)
        
        with col1:
            age = st.slider("Age", 18, 90, 30)
        with col2:
            education = st.slider("Education Level (years)", 1, 16, 12)
        with col3:
            hours = st.slider("Hours per Week", 20, 80, 40)
            
        # Make prediction
        input_data = scaler.transform([[age, education, hours]])
        prediction = model.predict(input_data)[0]
        
        st.metric("Predicted Economic Success Probability", f"{prediction:.1%}")

except Exception as e:
    st.error(f"Error loading data: {str(e)}")
    st.info("Please ensure the dataset is available in the data directory.")

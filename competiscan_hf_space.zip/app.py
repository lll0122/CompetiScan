from backend.app.main import app

# Hugging Face Spaces expects the FastAPI app object to be named `app` at the root level.

# Immigration Economic Impact Analysis

## Project Overview
This project develops a predictive model to evaluate potential immigrants based on their estimated lifetime economic contribution to the U.S. economy. The analysis includes:
- Income prediction
- Education impact analysis
- Employment potential assessment
- Innovation and entrepreneurship indicators

## Project Structure
```
immigration_analysis/
├── data/                  # Data storage
├── models/               # Trained models
├── src/                  # Source code
│   ├── data_prep.py     # Data preparation
│   ├── model.py         # ML model
│   └── visualization.py  # Visualization functions
├── app.py               # Streamlit dashboard
└── README.md           # Project documentation
```

## Features Analyzed
1. Demographics
   - Age
   - Education
   - Work experience
   - Country of origin

2. Economic Indicators
   - Current income
   - Occupation
   - Industry sector
   - Working hours

3. Skills & Potential
   - Education level
   - Technical skills
   - Language proficiency
   - Entrepreneurial background

## Model Metrics
The model evaluates candidates based on:
- Predicted income potential
- Innovation capacity score
- Entrepreneurship probability
- Tax contribution forecast

## Usage
1. Install requirements: `pip install -r requirements.txt`
2. Run dashboard: `streamlit run app.py`

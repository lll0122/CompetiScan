import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.ensemble import RandomForestClassifier, GradientBoostingRegressor
from sklearn.metrics import accuracy_score, mean_squared_error, r2_score
import shap

# Page config
st.set_page_config(
    page_title="Immigration Economic Impact Analysis",
    layout="wide"
)

# Title and introduction
st.title("Immigration Economic Impact Analysis Dashboard")
st.markdown("""
This dashboard analyzes potential economic contributions of immigrants based on various factors
including education, skills, and work experience. The model provides insights for merit-based
immigration policy decisions.
""")

# Load and preprocess data
@st.cache_data
def load_data():
    # Load the Adult Income dataset
    df = pd.read_csv('data/adult.csv')
    
    # Basic preprocessing
    df = df.replace(' ?', np.nan)
    df = df.dropna()
    
    # Create derived features
    df['education_num'] = pd.Categorical(df['education']).codes
    df['income_binary'] = (df['income'].str.contains('>50K')).astype(int)
    
    return df

# Load data
try:
    df = load_data()
    
    # Sidebar for navigation
    st.sidebar.title("Navigation")
    page = st.sidebar.radio(
        "Select Analysis",
        ["Overview", "Demographic Analysis", "Economic Potential", "Predictive Model"]
    )

    if page == "Overview":
        # Key metrics
        col1, col2, col3 = st.columns(3)
        
        with col1:
            high_income_pct = (df['income_binary'].mean() * 100).round(1)
            st.metric("High Income Potential", f"{high_income_pct}%")
            
        with col2:
            avg_education = df['education_num'].mean().round(1)
            st.metric("Average Education Level", f"{avg_education}/16")
            
        with col3:
            entrepreneurial_pct = (df['workclass'].str.contains('Self-emp').mean() * 100).round(1)
            st.metric("Entrepreneurship Rate", f"{entrepreneurial_pct}%")

        # Education vs Income
        st.subheader("Education Level Impact on High Income Probability")
        edu_income = df.groupby('education')['income_binary'].mean().sort_values(ascending=False)
        fig = px.bar(edu_income, 
                    title="Income Potential by Education Level",
                    labels={'value': 'Probability of High Income', 'education': 'Education Level'})
        st.plotly_chart(fig)

    elif page == "Demographic Analysis":
        st.header("Demographic Patterns and Economic Success")
        
        # Age distribution
        fig_age = px.histogram(df, x='age', color='income',
                             title="Age Distribution by Income Level",
                             labels={'age': 'Age', 'count': 'Number of Individuals'})
        st.plotly_chart(fig_age)
        
        # Education and occupation correlation
        st.subheader("Education and Occupation Analysis")
        edu_occ = pd.crosstab(df['education'], df['occupation'])
        fig_heatmap = px.imshow(edu_occ, 
                               title="Education-Occupation Distribution",
                               labels=dict(x="Occupation", y="Education Level"))
        st.plotly_chart(fig_heatmap)

    elif page == "Economic Potential":
        st.header("Economic Contribution Indicators")
        
        # Work hours analysis
        st.subheader("Working Hours and Income Relationship")
        hours_income = px.scatter(df, x='hours-per-week', y='income_binary',
                                title="Working Hours vs Income Potential",
                                labels={'hours-per-week': 'Hours per Week', 
                                       'income_binary': 'High Income Probability'})
        st.plotly_chart(hours_income)
        
        # Industry sector analysis
        industry_income = df.groupby('workclass')['income_binary'].mean().sort_values(ascending=False)
        fig_industry = px.bar(industry_income,
                            title="Income Potential by Industry Sector",
                            labels={'value': 'Probability of High Income', 
                                   'workclass': 'Industry Sector'})
        st.plotly_chart(fig_industry)

    else:  # Predictive Model
        st.header("Predictive Model Analysis")
        
        # Prepare features for modeling
        feature_cols = ['age', 'education_num', 'hours-per-week']
        X = df[feature_cols]
        y = df['income_binary']
        
        # Split and scale data
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        scaler = StandardScaler()
        X_train_scaled = scaler.fit_transform(X_train)
        X_test_scaled = scaler.transform(X_test)
        
        # Train model
        model = GradientBoostingRegressor(random_state=42)
        model.fit(X_train_scaled, y_train)
        
        # Model performance
        y_pred = model.predict(X_test_scaled)
        r2 = r2_score(y_test, y_pred)
        
        st.metric("Model R² Score", f"{r2:.3f}")
        
        # Feature importance
        importance_df = pd.DataFrame({
            'Feature': feature_cols,
            'Importance': model.feature_importances_
        }).sort_values('Importance', ascending=False)
        
        fig_importance = px.bar(importance_df, x='Feature', y='Importance',
                              title="Feature Importance in Predicting Economic Success")
        st.plotly_chart(fig_importance)
        
        # Interactive prediction
        st.subheader("Economic Potential Predictor")
        col1, col2, col3 = st.columns(3)
        
        with col1:
            age = st.slider("Age", 18, 90, 30)
        with col2:
            education = st.slider("Education Level (years)", 1, 16, 12)
        with col3:
            hours = st.slider("Hours per Week", 20, 80, 40)
            
        # Make prediction
        input_data = scaler.transform([[age, education, hours]])
        prediction = model.predict(input_data)[0]
        
        st.metric("Predicted Economic Success Probability", f"{prediction:.1%}")

except Exception as e:
    st.error(f"Error loading data: {str(e)}")
    st.info("Please ensure the dataset is available in the data directory.")

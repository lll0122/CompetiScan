import numpy as np
from sklearn.ensemble import GradientBoostingRegressor, RandomForestClassifier
from sklearn.metrics import accuracy_score, r2_score, mean_squared_error
import joblib
import shap

class EconomicPotentialModel:
    def __init__(self):
        self.income_model = GradientBoostingRegressor(
            n_estimators=100,
            learning_rate=0.1,
            max_depth=4,
            random_state=42
        )
        
        self.potential_model = RandomForestClassifier(
            n_estimators=100,
            max_depth=5,
            random_state=42
        )
        
        self.feature_importance = None
        self.shap_values = None
    
    def train_income_model(self, X_train, y_train):
        """
        Train the income prediction model
        """
        self.income_model.fit(X_train, y_train)
        self.feature_importance = {
            'income': dict(zip(
                range(X_train.shape[1]),
                self.income_model.feature_importances_
            ))
        }
        
        # Calculate SHAP values for interpretability
        explainer = shap.TreeExplainer(self.income_model)
        self.shap_values = explainer.shap_values(X_train)
    
    def train_potential_model(self, X_train, y_train):
        """
        Train the overall potential model
        """
        self.potential_model.fit(X_train, y_train)
        self.feature_importance['potential'] = dict(zip(
            range(X_train.shape[1]),
            self.potential_model.feature_importances_
        ))
    
    def predict_income(self, X):
        """
        Predict income potential
        """
        return self.income_model.predict(X)
    
    def predict_potential(self, X):
        """
        Predict overall economic potential
        """
        return self.potential_model.predict_proba(X)[:, 1]
    
    def evaluate_models(self, X_test, y_test_income, y_test_potential):
        """
        Evaluate both models' performance
        """
        # Income model evaluation
        income_pred = self.predict_income(X_test)
        income_r2 = r2_score(y_test_income, income_pred)
        income_rmse = np.sqrt(mean_squared_error(y_test_income, income_pred))
        
        # Potential model evaluation
        potential_pred = (self.predict_potential(X_test) > 0.5).astype(int)
        potential_accuracy = accuracy_score(y_test_potential, potential_pred)
        
        return {
            'income_r2': income_r2,
            'income_rmse': income_rmse,
            'potential_accuracy': potential_accuracy
        }
    
    def get_feature_importance(self):
        """
        Get feature importance for both models
        """
        return self.feature_importance
    
    def get_shap_values(self):
        """
        Get SHAP values for model interpretability
        """
        return self.shap_values
    
    def save_models(self, path_prefix):
        """
        Save both models to disk
        """
        joblib.dump(self.income_model, f'{path_prefix}_income.joblib')
        joblib.dump(self.potential_model, f'{path_prefix}_potential.joblib')
    
    def load_models(self, path_prefix):
        """
        Load both models from disk
        """
        self.income_model = joblib.load(f'{path_prefix}_income.joblib')
        self.potential_model = joblib.load(f'{path_prefix}_potential.joblib')

def create_composite_score(income_pred, potential_pred, weights=(0.6, 0.4)):
    """
    Create a composite score combining income and potential predictions
    """
    # Normalize predictions to 0-1 range
    income_norm = (income_pred - income_pred.min()) / (income_pred.max() - income_pred.min())
    
    # Calculate weighted average
    return weights[0] * income_norm + weights[1] * potential_pred

if __name__ == "__main__":
    # Test model functionality
    from sklearn.datasets import make_classification
    
    # Generate sample data
    X, y = make_classification(n_samples=1000, n_features=10, n_classes=2)
    X_train, X_test = X[:800], X[800:]
    y_train, y_test = y[:800], y[800:]
    
    # Test model
    model = EconomicPotentialModel()
    model.train_income_model(X_train, y_train)
    model.train_potential_model(X_train, y_train)
    
    # Test predictions
    income_pred = model.predict_income(X_test)
    potential_pred = model.predict_potential(X_test)
    
    # Create composite score
    scores = create_composite_score(income_pred, potential_pred)
    print("Model testing completed successfully")

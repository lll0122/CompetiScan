import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.model_selection import train_test_split

def load_and_clean_data(file_path):
    """
    Load and preprocess the Adult Income dataset
    """
    # Read data
    df = pd.read_csv(file_path)
    
    # Remove missing values
    df = df.replace(' ?', np.nan)
    df = df.dropna()
    
    # Create numeric features
    le = LabelEncoder()
    categorical_columns = ['workclass', 'education', 'marital-status', 
                         'occupation', 'relationship', 'race', 'sex', 
                         'native-country']
    
    for col in categorical_columns:
        df[f'{col}_encoded'] = le.fit_transform(df[col])
    
    # Create target variable
    df['income_binary'] = (df['income'].str.contains('>50K')).astype(int)
    
    # Create derived features
    df['education_num'] = pd.Categorical(df['education']).codes
    df['hours_category'] = pd.cut(df['hours-per-week'], 
                                bins=[0, 20, 40, 60, 100],
                                labels=['Part-time', 'Full-time', 'Overtime', 'Extreme'])
    
    # Calculate potential score (example metric)
    df['potential_score'] = (
        df['education_num'] * 0.4 +
        df['hours-per-week'].clip(0, 80) / 80 * 0.3 +
        (df['age'].between(25, 45)).astype(int) * 0.3
    )
    
    return df

def prepare_features(df):
    """
    Prepare features for modeling
    """
    # Select features
    feature_cols = [
        'age', 'education_num', 'hours-per-week',
        'workclass_encoded', 'occupation_encoded',
        'marital-status_encoded', 'relationship_encoded'
    ]
    
    X = df[feature_cols]
    y = df['income_binary']
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    
    # Scale features
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    return X_train_scaled, X_test_scaled, y_train, y_test, scaler, feature_cols

def calculate_economic_metrics(df):
    """
    Calculate additional economic metrics
    """
    metrics = {
        'high_income_rate': df['income_binary'].mean(),
        'avg_education_level': df['education_num'].mean(),
        'entrepreneurship_rate': df['workclass'].str.contains('Self-emp').mean(),
        'avg_hours_worked': df['hours-per-week'].mean(),
        'high_potential_rate': (df['potential_score'] > 0.7).mean()
    }
    
    return metrics

if __name__ == "__main__":
    # Test the functions
    try:
        df = load_and_clean_data('../data/adult.csv')
        print("Data loaded and cleaned successfully")
        
        X_train, X_test, y_train, y_test, scaler, features = prepare_features(df)
        print("Features prepared successfully")
        
        metrics = calculate_economic_metrics(df)
        print("\nKey Metrics:")
        for key, value in metrics.items():
            print(f"{key}: {value:.2f}")
            
    except Exception as e:
        print(f"Error: {str(e)}")

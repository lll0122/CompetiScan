import streamlit as st
import openai
import datetime
import pandas as pd
from typing import Dict

# --- CONFIGURABLE: Company Info & Qualifying Questions ---
COMPANY_NAME = st.secrets["company_name"] if "company_name" in st.secrets else "SoKat AI (Demo)"
COMPANY_LOGO = st.secrets["company_logo"] if "company_logo" in st.secrets else None
QUALIFYING_QUESTIONS = st.secrets["qualifying_questions"] if "qualifying_questions" in st.secrets else [
    "What is your company size?",
    "What is your role?",
    "What is your main business challenge?",
    "How urgent is your need for AI solutions?"
]

# --- Google Sheets Integration (placeholder) ---
def save_lead_to_excel(lead: Dict, filename="leads.xlsx"):
    try:
        df = pd.read_excel(filename)
    except FileNotFoundError:
        df = pd.DataFrame()
    df = pd.concat([df, pd.DataFrame([lead])], ignore_index=True)
    df.to_excel(filename, index=False)

# --- AI Lead Qualification (OpenAI) ---
def ai_score_lead(lead: Dict) -> str:
    prompt = f"""
You are an expert business development AI. Given the following lead information, score the lead as High, Medium, or Low potential and explain your reasoning.\n\nLead Info: {lead}\n\nScore and Reasoning:
"""
    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}]
        )
        return response.choices[0].message["content"].strip()
    except Exception as e:
        return f"AI error: {e}"

# --- AI Follow-up Suggestion ---
def ai_followup_message(lead: Dict, score: str) -> str:
    prompt = f"""
You are an expert business development assistant. Draft a personalized follow-up email to this lead, referencing their answers and the lead score ({score}).\n\nLead Info: {lead}\n\nEmail:
"""
    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}]
        )
        return response.choices[0].message["content"].strip()
    except Exception as e:
        return f"AI error: {e}"

# --- Streamlit UI ---
st.set_page_config(page_title=f"{COMPANY_NAME} Lead Generator", page_icon="🤖", layout="centered")

if COMPANY_LOGO:
    st.image(COMPANY_LOGO, width=160)
st.title(f"{COMPANY_NAME} Lead Generation Portal")
st.write("Please fill out the form below. Our AI will qualify your inquiry and suggest a follow-up!")

with st.form("lead_form"):
    name = st.text_input("Your Name")
    email = st.text_input("Your Email")
    company = st.text_input("Company Name")
    answers = {}
    for q in QUALIFYING_QUESTIONS:
        answers[q] = st.text_input(q)
    submitted = st.form_submit_button("Submit Lead")

if submitted:
    lead = {
        "timestamp": datetime.datetime.now().isoformat(),
        "name": name,
        "email": email,
        "company": company,
    }
    lead.update(answers)
    with st.spinner("Scoring your lead..."):
        score_and_reason = ai_score_lead(lead)
    with st.spinner("Drafting a follow-up message..."):
        followup = ai_followup_message(lead, score_and_reason)
    save_lead_to_excel({**lead, "score": score_and_reason, "followup": followup})
    st.success("Lead submitted and scored!")
    st.markdown(f"**Lead Score & Reasoning:**\n{score_and_reason}")
    st.markdown(f"**Suggested Follow-up Email:**\n{followup}")
    st.info("Your lead is saved to Excel. For Google Sheets integration, add your credentials.")

st.caption("Built with ❤️ for SoKat AI. Configurable for any company.")

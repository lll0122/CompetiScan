import pandas as pd
import matplotlib.pyplot as plt
from ucimlrepo import fetch_ucirepo

# Fetch the iris dataset
iris = fetch_ucirepo(id=53)
X = iris.data.features
y = iris.data.targets

# Combine features and target into one dataframe
df = pd.concat([X, y], axis=1)

# Display first few rows
print("\nFirst 5 rows of the dataset:")
print(df.head())

# Display statistical summary
print("\nStatistical summary of the dataset:")
print(df.describe())

# Check for missing values
print("\nMissing values in the dataset:")
print(df.isnull().sum())

# Create histograms for each feature
plt.figure(figsize=(12, 8))

# Plot histograms
plt.subplot(2, 2, 1)
plt.hist(df['sepal length'], bins=20, edgecolor='black')
plt.title('Sepal Length Distribution')
plt.xlabel('Length (cm)')
plt.ylabel('Frequency')

plt.subplot(2, 2, 2)
plt.hist(df['sepal width'], bins=20, edgecolor='black')
plt.title('Sepal Width Distribution')
plt.xlabel('Width (cm)')
plt.ylabel('Frequency')

plt.subplot(2, 2, 3)
plt.hist(df['petal length'], bins=20, edgecolor='black')
plt.title('Petal Length Distribution')
plt.xlabel('Length (cm)')
plt.ylabel('Frequency')

plt.subplot(2, 2, 4)
plt.hist(df['petal width'], bins=20, edgecolor='black')
plt.title('Petal Width Distribution')
plt.xlabel('Width (cm)')
plt.ylabel('Frequency')

plt.tight_layout()
plt.show()

# Create a box plot for all features
plt.figure(figsize=(10, 6))
df.boxplot(column=['sepal length', 'sepal width', 'petal length', 'petal width'])
plt.title('Box Plot of Iris Features')
plt.ylabel('Centimeters')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# Print class distribution
print("\nClass distribution in the dataset:")
print(df['class'].value_counts())

import os
import datetime as dt
import streamlit as st
import openai
import gspread
from google.oauth2.service_account import Credentials
import json

OPENAI_API_KEY = "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"  # (your real API key, no line breaks)
openai.api_key = OPENAI_API_KEY
st.set_page_config(page_title="LeadGen", layout="centered")
# --- Sidebar: Company Customization ---
st.sidebar.header("Company Settings")
company_name = st.sidebar.text_input("Company Name", value="SoKat AI (Demo)")
company_logo = st.sidebar.text_input("Logo URL (optional)", value="")
qualifying_questions = st.sidebar.text_area(
    "Qualifying Questions (one per line)",
    value="""What is your company size?\nWhat is your role?\nWhat is your main business challenge?\nHow urgent is your need for AI solutions?"""
).splitlines()

# --- Google Sheets Setup ---
def get_sheet():
    scopes = ["https://www.googleapis.com/auth/spreadsheets"]
    creds = Credentials.from_service_account_file(
        os.getenv("GOOGLE_APPLICATION_CREDENTIALS"), scopes=scopes
    )
    client = gspread.authorize(creds)
    return client.open_by_key(os.getenv("LEAD_SHEET_ID")).sheet1

# --- AI Qualification ---
def qualify_lead(data: dict):
    prompt = f"""
You are a top-tier BDR. Score this incoming lead on a 0–100 scale and suggest a next step.\nLead data:\n{data}\nReturn JSON with fields: score, next_step, tags (list of strings)
"""
    resp = openai.ChatCompletion.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}]
    )
    return resp.choices[0].message.content

# --- AI Follow-Up Email ---
def followup_email(data: dict, ai_json: str):
    prompt = f"""
Given this lead and AI qualification result, draft a personalized follow-up email:\nLead: {data}\nAI Result: {ai_json}\nEmail:
"""
    resp = openai.ChatCompletion.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}]
    )
    return resp.choices[0].message.content

# --- UI ---
if company_logo:
    st.image(company_logo, width=180)
st.title(f"🤖 {company_name} LeadGen Portal")
st.caption("Configurable for any company. Built with ❤️ by SoKat.")

with st.form("lead_form", clear_on_submit=True):
    name = st.text_input("Contact Name")
    email = st.text_input("Contact Email")
    company = st.text_input("Lead Company Name")
    answers = {}
    for q in qualifying_questions:
        answers[q] = st.text_input(q)
    submit = st.form_submit_button("Qualify & Save Lead")

if submit:
    lead = {"timestamp": dt.datetime.utcnow().isoformat(), "name": name, "email": email, "company": company}
    lead.update(answers)
    with st.spinner("Scoring lead…"):
        ai_json = qualify_lead(lead)
    with st.spinner("Drafting follow-up…"):
        followup = followup_email(lead, ai_json)
    st.success("✅ Lead Scored & Saved!")
    st.subheader("AI Qualification Result")
    st.json(json.loads(ai_json))
    st.subheader("Suggested Follow-Up Email")
    st.write(followup)
    # Save to Google Sheets
    try:
        sheet = get_sheet()
        sheet.append_row([
            lead["timestamp"], name, email, company,
            json.dumps(answers), ai_json, followup
        ])
        st.toast("Saved to Google Sheets")
    except Exception as e:
        st.error(f"Error saving to Google Sheets: {e}")

# --- Show Recent Leads (Optional) ---
if st.sidebar.button("Show Recent Leads"):
    try:
        sheet = get_sheet()
        data = sheet.get_all_records()
        st.sidebar.write(data[-5:])
    except Exception as e:
        st.sidebar.error(f"Error loading leads: {e}")

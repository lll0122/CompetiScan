# CompetiScan Frontend

This directory will contain the React-based dashboard for the AI Competitor Intelligence Tracker.

## Features (MVP)
- Competitor list and add form
- Table of recent events
- Trend charts (from backend)
- Manual trigger for scraping
- Auth (MVP)
